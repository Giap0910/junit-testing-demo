# Issue 2: Viết các ca kiểm thử JUnit để bao phủ tất cả các đường đi khả thi

## Mục tiêu
Viết các ca kiểm thử JUnit để bao phủ tất cả các đường đi khả thi của `TransactionAnalyzer.classifyTransactions()`.

## Giải thích phạm vi
Phương thức chỉ xử lý tối đa 2 phần tử đầu tiên, nên các đường đi khả thi là hữu hạn:

1. 0 lần lặp
2. 1 lần lặp với nhánh không âm
3. 1 lần lặp với nhánh âm
4. 2 lần lặp: không âm -> không âm
5. 2 lần lặp: không âm -> âm
6. 2 lần lặp: âm -> không âm
7. 2 lần lặp: âm -> âm

## Điều kiện hoàn thành
- Có test tương ứng cho cả 7 đường đi khả thi ở trên
- Tất cả test chạy thành công
