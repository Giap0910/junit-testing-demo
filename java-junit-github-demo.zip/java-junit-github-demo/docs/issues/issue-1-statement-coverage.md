# Issue 1: Viết các ca kiểm thử JUnit để bao phủ tất cả các lệnh

## Mục tiêu
Viết các ca kiểm thử JUnit cho `TransactionAnalyzer.classifyTransactions()` để bao phủ toàn bộ các lệnh trong chương trình.

## Điều kiện hoàn thành
- Có test cho trường hợp mảng rỗng
- Có test cho trường hợp chỉ có số không âm
- Có test cho trường hợp chỉ có số âm
- Có test cho trường hợp vừa có số âm vừa có số không âm
- Tất cả test chạy thành công
