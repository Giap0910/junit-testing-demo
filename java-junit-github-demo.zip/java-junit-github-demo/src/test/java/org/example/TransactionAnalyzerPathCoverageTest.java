package org.example;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class TransactionAnalyzerPathCoverageTest {

    private final TransactionAnalyzer analyzer = new TransactionAnalyzer();

    @Test
    void path1_zeroIterations() {
        assertEquals("EMPTY", analyzer.classifyTransactions(new int[]{}));
    }

    @Test
    void path2_oneIteration_nonNegative() {
        assertEquals("NON_NEGATIVE_ONLY", analyzer.classifyTransactions(new int[]{4}));
    }

    @Test
    void path3_oneIteration_negative() {
        assertEquals("WITHDRAWAL_ONLY", analyzer.classifyTransactions(new int[]{-4}));
    }

    @Test
    void path4_twoIterations_nonNegativeThenNonNegative() {
        assertEquals("NON_NEGATIVE_ONLY", analyzer.classifyTransactions(new int[]{4, 2}));
    }

    @Test
    void path5_twoIterations_nonNegativeThenNegative() {
        assertEquals("MIXED", analyzer.classifyTransactions(new int[]{4, -2}));
    }

    @Test
    void path6_twoIterations_negativeThenNonNegative() {
        assertEquals("MIXED", analyzer.classifyTransactions(new int[]{-4, 2}));
    }

    @Test
    void path7_twoIterations_negativeThenNegative() {
        assertEquals("WITHDRAWAL_ONLY", analyzer.classifyTransactions(new int[]{-4, -2}));
    }
}
