package org.example;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class TransactionAnalyzerStatementCoverageTest {

    private final TransactionAnalyzer analyzer = new TransactionAnalyzer();

    @Test
    void shouldReturnEmptyWhenArrayIsEmpty() {
        assertEquals("EMPTY", analyzer.classifyTransactions(new int[]{}));
    }

    @Test
    void shouldReturnNonNegativeOnlyWhenValuesAreZeroOrPositive() {
        assertEquals("NON_NEGATIVE_ONLY", analyzer.classifyTransactions(new int[]{5, 0}));
    }

    @Test
    void shouldReturnWithdrawalOnlyWhenAllProcessedValuesAreNegative() {
        assertEquals("WITHDRAWAL_ONLY", analyzer.classifyTransactions(new int[]{-3, -8}));
    }

    @Test
    void shouldReturnMixedWhenProcessedValuesContainNegativeAndNonNegative() {
        assertEquals("MIXED", analyzer.classifyTransactions(new int[]{7, -1}));
    }
}
