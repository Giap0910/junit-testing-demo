package org.example;

import java.util.Arrays;

/**
 * Simple program for a software testing assignment.
 *
 * The method intentionally analyzes at most the first 2 transactions so that
 * all feasible execution paths remain finite and easy to cover with JUnit tests.
 */
public class TransactionAnalyzer {

    public String classifyTransactions(int[] transactions) {
        if (transactions == null) {
            throw new IllegalArgumentException("transactions must not be null");
        }

        int processed = Math.min(transactions.length, 2);
        boolean sawNonNegative = false;
        boolean sawNegative = false;

        for (int i = 0; i < processed; i++) {
            int value = transactions[i];
            if (value >= 0) {
                sawNonNegative = true;
            } else {
                sawNegative = true;
            }
        }

        if (processed == 0) {
            return "EMPTY";
        }
        if (sawNonNegative && sawNegative) {
            return "MIXED";
        }
        if (sawNegative) {
            return "WITHDRAWAL_ONLY";
        }
        return "NON_NEGATIVE_ONLY";
    }

    public String describe(int[] transactions) {
        return Arrays.toString(transactions) + " -> " + classifyTransactions(transactions);
    }
}
