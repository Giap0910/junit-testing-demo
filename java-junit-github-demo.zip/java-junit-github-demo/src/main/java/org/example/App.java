package org.example;

/**
 * Demo entry point.
 */
public class App {

    public static void main(String[] args) {
        TransactionAnalyzer analyzer = new TransactionAnalyzer();

        int[] sample1 = {10, 0};
        int[] sample2 = {-5, 20};
        int[] sample3 = {};

        System.out.println(analyzer.describe(sample1));
        System.out.println(analyzer.describe(sample2));
        System.out.println(analyzer.describe(sample3));
    }
}
